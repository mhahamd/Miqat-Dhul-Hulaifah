/**
 * نموذج الأعمال الإنشائية - مسجد ميقات ذو الحليفة
 * ملف JavaScript للوظائف التفاعلية
 */

// تحميل الصفحة
document.addEventListener('DOMContentLoaded', function() {
    initializeForm();
    setCurrentDate();
});

/**
 * تهيئة النموذج
 */
function initializeForm() {
    // إضافة مستمعي الأحداث للحقول
    const form = document.getElementById('constructionForm');
    const inputs = form.querySelectorAll('input, textarea, select');
    
    inputs.forEach(input => {
        input.addEventListener('input', validateField);
        input.addEventListener('blur', validateField);
    });
    
    // تحسين تجربة المستخدم
    addInputEnhancements();
}

/**
 * تعيين التاريخ الحالي
 */
function setCurrentDate() {
    const dateInput = document.getElementById('workDate');
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0];
    dateInput.value = formattedDate;
}

/**
 * عرض اسم الملف المحدد
 */
function displayFileName(input) {
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    
    if (input.files && input.files[0]) {
        const file = input.files[0];
        const fileName = file.name;
        const fileSize = (file.size / 1024 / 1024).toFixed(2); // بالميجابايت
        
        // التحقق من حجم الملف (5 ميجابايت كحد أقصى)
        if (file.size > 5 * 1024 * 1024) {
            alert('حجم الملف كبير جداً. الحد الأقصى المسموح: 5 ميجابايت');
            input.value = '';
            fileNameDisplay.innerHTML = '';
            return;
        }
        
        fileNameDisplay.innerHTML = `
            <div style="display: flex; align-items: center; gap: 10px;">
                <span style="color: var(--success-color);">✓</span>
                <span>تم اختيار الملف: <strong>${fileName}</strong></span>
                <span style="color: var(--text-secondary);">(${fileSize} ميجابايت)</span>
                <button type="button" onclick="removeFile()" style="background: none; border: none; color: #dc3545; cursor: pointer; font-size: 1.2rem;">×</button>
            </div>
        `;
    } else {
        fileNameDisplay.innerHTML = '';
    }
}

/**
 * إزالة الملف المحدد
 */
function removeFile() {
    const fileInput = document.getElementById('attachedFile');
    const fileNameDisplay = document.getElementById('fileNameDisplay');
    
    fileInput.value = '';
    fileNameDisplay.innerHTML = '';
}

/**
 * التحقق من صحة الحقل
 */
function validateField(event) {
    const field = event.target;
    const value = field.value.trim();
    
    // إزالة رسائل الخطأ السابقة
    removeErrorMessage(field);
    
    // التحقق من الحقول المطلوبة
    if (field.hasAttribute('required') && !value) {
        showErrorMessage(field, 'هذا الحقل مطلوب');
        return false;
    }
    
    // التحقق من رقم الهاتف
    if (field.type === 'tel' && value) {
        const phonePattern = /^[0-9]{10}$/;
        if (!phonePattern.test(value.replace(/\s/g, ''))) {
            showErrorMessage(field, 'يرجى إدخال رقم هاتف صحيح (10 أرقام)');
            return false;
        }
    }
    
    // التحقق من التاريخ
    if (field.type === 'date' && value) {
        const selectedDate = new Date(value);
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        if (selectedDate > today) {
            showErrorMessage(field, 'لا يمكن اختيار تاريخ في المستقبل');
            return false;
        }
    }
    
    return true;
}

/**
 * عرض رسالة خطأ
 */
function showErrorMessage(field, message) {
    const errorDiv = document.createElement('div');
    errorDiv.className = 'error-message';
    errorDiv.style.cssText = `
        color: #dc3545;
        font-size: 0.9rem;
        margin-top: 5px;
        display: block;
    `;
    errorDiv.textContent = message;
    
    field.style.borderColor = '#dc3545';
    field.parentNode.appendChild(errorDiv);
}

/**
 * إزالة رسالة الخطأ
 */
function removeErrorMessage(field) {
    const errorMessage = field.parentNode.querySelector('.error-message');
    if (errorMessage) {
        errorMessage.remove();
    }
    field.style.borderColor = '';
}

/**
 * التحقق من صحة النموذج كاملاً
 */
function validateForm() {
    const form = document.getElementById('constructionForm');
    const requiredFields = form.querySelectorAll('[required]');
    let isValid = true;
    
    requiredFields.forEach(field => {
        if (!validateField({ target: field })) {
            isValid = false;
        }
    });
    
    return isValid;
}

/**
 * طباعة النموذج
 */
function printForm() {
    // التحقق من صحة البيانات
    if (!validateForm()) {
        alert('يرجى تعبئة جميع الحقول المطلوبة بشكل صحيح قبل الطباعة');
        return;
    }
    
    // جمع البيانات من النموذج
    const formData = collectFormData();
    
    // تعبئة منطقة الطباعة
    populatePrintArea(formData);
    
    // إنشاء محتوى الطباعة
    const printContent = createPrintContent(formData);
    
    // إنشاء نافذة طباعة جديدة
    const printWindow = window.open('', '_blank', 'width=800,height=600');
    
    if (printWindow) {
        printWindow.document.write(printContent);
        printWindow.document.close();
        
        // انتظار تحميل المحتوى ثم الطباعة
        printWindow.onload = function() {
            setTimeout(() => {
                printWindow.focus();
                printWindow.print();
                printWindow.close();
            }, 500);
        };
    } else {
        alert('تعذر فتح نافذة الطباعة. يرجى السماح بالنوافذ المنبثقة.');
    }
}

/**
 * إنشاء محتوى الطباعة
 */
function createPrintContent(formData) {
    return `
        <!DOCTYPE html>
        <html lang="ar" dir="rtl">
        <head>
            <meta charset="UTF-8">
            <title>نموذج الأعمال الإنشائية - مسجد ميقات ذو الحليفة</title>
            <style>
                body {
                    font-family: 'Tahoma', 'Arial', sans-serif;
                    direction: rtl;
                    text-align: right;
                    margin: 20px;
                    line-height: 1.6;
                    color: #333;
                }
                .print-header {
                    text-align: center;
                    margin-bottom: 30px;
                    padding: 20px;
                    border: 3px solid #8B4513;
                    border-radius: 10px;
                    background: linear-gradient(135deg, #f8f9fa 0%, #ffffff 100%);
                }
                .print-header h1 {
                    color: #8B4513;
                    font-size: 2rem;
                    margin-bottom: 10px;
                    font-weight: bold;
                }
                .print-header h2 {
                    color: #A0522D;
                    font-size: 1.3rem;
                    margin-bottom: 0;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin: 20px 0;
                    font-size: 1rem;
                }
                td {
                    padding: 12px;
                    border: 2px solid #333;
                    vertical-align: top;
                }
                td:first-child {
                    background: #f5f5f5;
                    font-weight: bold;
                    width: 30%;
                }
                .print-signatures {
                    margin-top: 60px;
                    page-break-inside: avoid;
                    display: flex;
                    justify-content: space-between;
                }
                .signature-section {
                    width: 45%;
                    text-align: center;
                }
                .signature-line {
                    border-bottom: 2px solid #000;
                    width: 200px;
                    margin: 20px auto;
                }
                .print-footer {
                    margin-top: 40px;
                    text-align: center;
                    font-size: 0.9rem;
                    color: #666;
                    border-top: 1px solid #ccc;
                    padding-top: 20px;
                }
                @media print {
                    body { margin: 0; }
                    .print-header { break-inside: avoid; }
                    .print-signatures { break-inside: avoid; }
                }
            </style>
        </head>
        <body>
            <div class="print-header">
                <h1>نموذج الأعمال الإنشائية</h1>
                <h2>مسجد ميقات ذو الحليفة</h2>
                <hr style="border: 2px solid #8B4513; margin: 20px 0;">
            </div>
            
            <div class="print-content">
                <table>
                    <tr>
                        <td>اسم الشركة:</td>
                        <td>${formData.companyName}</td>
                    </tr>
                    <tr>
                        <td>اسم المشرف / المهندس:</td>
                        <td>${formData.supervisorName}</td>
                    </tr>
                    <tr>
                        <td>مدة العمل المستغرقة:</td>
                        <td>${formData.workDuration}</td>
                    </tr>
                    <tr>
                        <td>التاريخ:</td>
                        <td>${formData.workDate}</td>
                    </tr>
                    <tr>
                        <td>رقم الهاتف:</td>
                        <td>${formData.phoneNumber}</td>
                    </tr>
                    <tr>
                        <td>وصف العمل:</td>
                        <td>${formData.workDescription}</td>
                    </tr>
                </table>
                
                <div class="print-signatures">
                    <div class="signature-section">
                        <p style="font-weight: bold; margin-bottom: 30px;">توقيع المهندس أو مشرف الشركة</p>
                        <div class="signature-line"></div>
                        <p style="margin-top: 10px;">الاسم: ___________________</p>
                    </div>
                    <div class="signature-section">
                        <p style="font-weight: bold; margin-bottom: 30px;">توقيع مشرف الفترة أو المدير المناوب</p>
                        <div class="signature-line"></div>
                        <p style="margin-top: 10px;">الاسم: ___________________</p>
                    </div>
                </div>
                
                <div class="print-footer">
                    <p>تم إنشاء هذا النموذج في: ${new Date().toLocaleDateString('ar-SA')} - ${new Date().toLocaleTimeString('ar-SA')}</p>
                </div>
            </div>
        </body>
        </html>
    `;
}

/**
 * جمع بيانات النموذج
 */
function collectFormData() {
    return {
        companyName: document.getElementById('companyName').value,
        supervisorName: document.getElementById('supervisorName').value,
        workDuration: document.getElementById('workDuration').value,
        workDate: formatDate(document.getElementById('workDate').value),
        phoneNumber: document.getElementById('phoneNumber').value,
        workDescription: document.getElementById('workDescription').value || 'لم يتم تحديد وصف',
        attachedFile: document.getElementById('attachedFile').files[0]?.name || 'لا يوجد ملف مرفق'
    };
}

/**
 * تعبئة منطقة الطباعة بالبيانات
 */
function populatePrintArea(data) {
    document.getElementById('printCompanyName').textContent = data.companyName;
    document.getElementById('printSupervisorName').textContent = data.supervisorName;
    document.getElementById('printWorkDuration').textContent = data.workDuration;
    document.getElementById('printWorkDate').textContent = data.workDate;
    document.getElementById('printPhoneNumber').textContent = data.phoneNumber;
    document.getElementById('printWorkDescription').textContent = data.workDescription;
    
    // تاريخ إنشاء النموذج
    const now = new Date();
    const generationDate = now.toLocaleDateString('ar-SA') + ' - ' + now.toLocaleTimeString('ar-SA');
    document.getElementById('printGenerationDate').textContent = generationDate;
}

/**
 * تنسيق التاريخ
 */
function formatDate(dateString) {
    if (!dateString) return '';
    
    const date = new Date(dateString);
    const options = { 
        year: 'numeric', 
        month: 'long', 
        day: 'numeric',
        weekday: 'long'
    };
    
    return date.toLocaleDateString('ar-SA', options);
}

/**
 * إعادة تعيين النموذج
 */
function resetForm() {
    if (confirm('هل أنت متأكد من إعادة تعيين جميع البيانات؟')) {
        const form = document.getElementById('constructionForm');
        form.reset();
        
        // إزالة رسائل الخطأ
        const errorMessages = document.querySelectorAll('.error-message');
        errorMessages.forEach(msg => msg.remove());
        
        // إزالة تنسيق الخطأ من الحقول
        const fields = form.querySelectorAll('input, textarea, select');
        fields.forEach(field => {
            field.style.borderColor = '';
        });
        
        // مسح عرض اسم الملف
        document.getElementById('fileNameDisplay').innerHTML = '';
        
        // إعادة تعيين التاريخ الحالي
        setCurrentDate();
        
        // رسالة تأكيد
        showSuccessMessage('تم إعادة تعيين النموذج بنجاح');
    }
}

/**
 * عرض رسالة نجاح
 */
function showSuccessMessage(message) {
    const successDiv = document.createElement('div');
    successDiv.style.cssText = `
        position: fixed;
        top: 20px;
        right: 20px;
        background: var(--success-color);
        color: white;
        padding: 15px 20px;
        border-radius: 8px;
        box-shadow: 0 4px 15px rgba(0,0,0,0.2);
        z-index: 1000;
        font-weight: 600;
    `;
    successDiv.textContent = message;
    
    document.body.appendChild(successDiv);
    
    // إزالة الرسالة بعد 3 ثوان
    setTimeout(() => {
        successDiv.remove();
    }, 3000);
}

/**
 * تحسينات إضافية لتجربة المستخدم
 */
function addInputEnhancements() {
    // تنسيق رقم الهاتف تلقائياً
    const phoneInput = document.getElementById('phoneNumber');
    phoneInput.addEventListener('input', function(e) {
        let value = e.target.value.replace(/\D/g, '');
        if (value.length > 10) {
            value = value.substring(0, 10);
        }
        e.target.value = value;
    });
    
    // تحسين حقل مدة العمل
    const durationInput = document.getElementById('workDuration');
    durationInput.addEventListener('input', function(e) {
        // إضافة اقتراحات تلقائية
        const suggestions = ['يوم واحد', 'يومان', '3 أيام', 'أسبوع', 'أسبوعان', 'شهر'];
        // يمكن إضافة منطق الاقتراحات هنا
    });
    
    // حفظ البيانات محلياً (Local Storage)
    const form = document.getElementById('constructionForm');
    const inputs = form.querySelectorAll('input:not([type="file"]), textarea, select');
    
    inputs.forEach(input => {
        // استرجاع البيانات المحفوظة
        const savedValue = localStorage.getItem(`form_${input.id}`);
        if (savedValue && input.type !== 'date') {
            input.value = savedValue;
        }
        
        // حفظ البيانات عند التغيير
        input.addEventListener('input', function() {
            localStorage.setItem(`form_${input.id}`, input.value);
        });
    });
}

/**
 * مسح البيانات المحفوظة محلياً
 */
function clearLocalStorage() {
    const form = document.getElementById('constructionForm');
    const inputs = form.querySelectorAll('input, textarea, select');
    
    inputs.forEach(input => {
        localStorage.removeItem(`form_${input.id}`);
    });
}

// إضافة مستمع لمسح البيانات المحفوظة عند إعادة التعيين
window.addEventListener('beforeunload', function() {
    // يمكن إضافة تأكيد حفظ البيانات هنا إذا لزم الأمر
});

// تصدير الوظائف للاستخدام العام
window.printForm = printForm;
window.resetForm = resetForm;
window.displayFileName = displayFileName;
window.removeFile = removeFile;

